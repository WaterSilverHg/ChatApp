// AsyncWebSocketListener.hpp (异步WebSocket业务处理器)
#pragma once

#include "global.h"
#include "oatpp-websocket/AsyncWebSocket.hpp"
#include "../dto/WebSocketMessageDto.hpp"
#include "../dto/MessageDto.hpp"
#include "../dto/ConversationDto.hpp"
#include "../dto/FriendDto.hpp"
#include "../dto/GroupDto.hpp"
#include "../dto/UserStatusDto.hpp"
#include "../vo/MessageVo.hpp"
#include "../vo/GroupVo.hpp"
#include "../vo/AuthVo.hpp"
#include "../vo/CommonVo.hpp"
#include "../vo/ConversationVO.hpp"
#include "../vo/FriendVO.hpp"
#include "../vo/NotificationVO.hpp"
#include "../vo/UserStatusVO.hpp"
#include "../service/ConversationService.hpp"
#include "../service/FriendService.hpp"
#include "../service/GroupService.hpp"
#include "../service/MessageService.hpp"
//#include "../service/NotificationService.hpp"
#include "../service/UserStatusService.hpp"
#include "../postgresql/AppClient.hpp"
#include "../../jwt/Appjwt.h"
#include "../../websocket/AppWebSocket.hpp"

#include <unordered_map>
#include <functional>

class AsyncWebSocketListener : public oatpp::websocket::AsyncWebSocket::Listener {
private:
    oatpp::data::stream::BufferOutputStream m_messageBuffer;
    oatpp::String m_userUuid;
    std::shared_ptr<AppClient> m_appClient;
    std::shared_ptr<Appjwt> m_jwt;
    std::shared_ptr<AppWebSocket> m_webSocket;
    std::shared_ptr<oatpp::data::mapping::ObjectMapper> m_objectMapper;
    std::shared_ptr<ConversationService> m_conversationService;
    std::shared_ptr<FriendService> m_friendService;
    std::shared_ptr<GroupService> m_groupService;
    std::shared_ptr<MessageService> m_messageService;
    //std::shared_ptr<NotificationService> m_notificationService;
    std::shared_ptr<UserStatusService> m_statusService;

    std::shared_ptr<AsyncWebSocket> m_socket;
    std::atomic<std::chrono::steady_clock::time_point> m_lastPongTime;
    std::atomic<bool> m_running;
    std::thread m_heartbeatThread;
    static constexpr auto HEARTBEAT_INTERVAL = std::chrono::seconds(10);
    static constexpr auto PONG_TIMEOUT = std::chrono::seconds(12);

    using FastMessageHandler = std::function<void(const oatpp::String&, const oatpp::String&)>;
    std::unordered_map<std::string, FastMessageHandler> m_handlers;

public:
    AsyncWebSocketListener(const oatpp::String& userUuid,
        const std::shared_ptr<AppClient>& appClient,
        const std::shared_ptr<Appjwt>& jwt,
        const std::shared_ptr<AppWebSocket>& websocket,
        const std::shared_ptr<oatpp::data::mapping::ObjectMapper>& objectMapper)
        : m_userUuid(userUuid)
        , m_appClient(appClient)
        , m_jwt(jwt)
        , m_webSocket(websocket)
        , m_objectMapper(objectMapper)
        , m_conversationService(std::make_shared<ConversationService>(appClient))
        , m_friendService(std::make_shared<FriendService>(appClient))
        , m_groupService(std::make_shared<GroupService>(appClient))
        , m_messageService(std::make_shared<MessageService>(appClient))
        //, m_notificationService(std::make_shared<NotificationService>(appClient))
        , m_statusService(std::make_shared<UserStatusService>(appClient))
        , m_lastPongTime(std::chrono::steady_clock::now())
        , m_running(true)
    {
        if (m_userUuid) {
            OATPP_LOGI("WebSocket", "User connected: %s", m_userUuid->c_str());
        }
        initHandlers();
    }

    void initHandlers() {
        // 会话相关 (ConversationController) - 仅保留markConversationRead
        registerHandler("get_conversations", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetConversations(userUuid, msg); });
        registerHandler("mark_conversation_read", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleMarkConversationRead(userUuid, msg); });

        // 好友相关 (FriendController)
        registerHandler("send_friend_request", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleSendFriendRequest(userUuid, msg); });
        registerHandler("get_sent_requests", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetSentRequests(userUuid, msg); });
        registerHandler("get_received_requests", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetReceivedRequests(userUuid, msg); });
        registerHandler("accept_friend_request", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleAcceptFriendRequest(userUuid, msg); });
        registerHandler("reject_friend_request", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleRejectFriendRequest(userUuid, msg); });
        registerHandler("cancel_friend_request", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleCancelFriendRequest(userUuid, msg); });
        registerHandler("get_friends", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetFriends(userUuid, msg); });
        registerHandler("update_friend_remark", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleUpdateFriendRemark(userUuid, msg); });
        registerHandler("update_friend_group", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleUpdateFriendGroup(userUuid, msg); });
        registerHandler("delete_friend", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleDeleteFriend(userUuid, msg); });
        registerHandler("block_user", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleBlockUser(userUuid, msg); });
        registerHandler("unblock_user", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleUnblockUser(userUuid, msg); });

        // 群组相关 (GroupController)
        registerHandler("create_group", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleCreateGroup(userUuid, msg); });
        registerHandler("get_my_groups", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetMyGroups(userUuid, msg); });
        registerHandler("get_group_detail", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetGroupDetail(userUuid, msg); });
        registerHandler("update_group", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleUpdateGroup(userUuid, msg); });
        registerHandler("dissolve_group", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleDissolveGroup(userUuid, msg); });
        registerHandler("get_group_members", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetGroupMembers(userUuid, msg); });
        registerHandler("add_group_members", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleAddGroupMembers(userUuid, msg); });
        registerHandler("remove_group_member", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleRemoveGroupMember(userUuid, msg); });
        registerHandler("set_member_role", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleSetMemberRole(userUuid, msg); });
        registerHandler("join_group", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleJoinGroup(userUuid, msg); });
        registerHandler("leave_group", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleLeaveGroup(userUuid, msg); });

        // 消息历史相关 (MessageController)
        registerHandler("get_private_messages", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetPrivateMessages(userUuid, msg); });
        registerHandler("get_private_messages_page", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetPrivateMessagesPage(userUuid, msg); });
        registerHandler("send_private_message", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleSendPrivateMessage(userUuid, msg); });
        registerHandler("mark_message_read", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleMarkMessageRead(userUuid, msg); });
        registerHandler("recall_message", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleRecallMessage(userUuid, msg); });
        registerHandler("get_group_messages", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetGroupMessages(userUuid, msg); });
        registerHandler("get_group_messages_page", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetGroupMessagesPage(userUuid, msg); });
        registerHandler("send_group_message", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleSendGroupMessage(userUuid, msg); });

        // 通知相关 (NotificationController)
        //registerHandler("get_notifications", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetNotifications(userUuid, msg); });
        //registerHandler("get_unread_count", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetUnreadCount(userUuid, msg); });
        //registerHandler("mark_notification_read", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleMarkNotificationRead(userUuid, msg); });
        //registerHandler("mark_all_notifications_read", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleMarkAllNotificationsRead(userUuid, msg); });
        //registerHandler("delete_notification", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleDeleteNotification(userUuid, msg); });
        //registerHandler("batch_delete_notifications", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleBatchDeleteNotifications(userUuid, msg); });
        //registerHandler("clear_notifications", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleClearNotifications(userUuid, msg); });

        // 用户状态相关 (UserStatusController)
        registerHandler("update_status", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleUpdateStatus(userUuid, msg); });
        registerHandler("get_multiple_statuses", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetMultipleStatuses(userUuid, msg); });
        registerHandler("get_current_user", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleGetCurrentUser(userUuid, msg); });
        registerHandler("update_user_info", [this](const oatpp::String& userUuid, const oatpp::String& msg) { handleUpdateUserInfo(userUuid, msg); });
    }

    void registerHandler(const std::string& type, FastMessageHandler handler) {
        m_handlers[type] = handler;
    }

    std::string quickExtractType(const oatpp::String& message) {
        if (!message || message->empty()) {
            return "";
        }

        const char* data = message->data();
        size_t len = message->size();
        const char* typePattern = "\"type\"";
        size_t typeLen = 6;

        for (size_t i = 0; i < len - typeLen; ++i) {
            if (memcmp(data + i, typePattern, typeLen) == 0) {
                size_t pos = i + typeLen;

                while (pos < len && (data[pos] == ' ' || data[pos] == '\t' || data[pos] == '\n' || data[pos] == '\r')) {
                    ++pos;
                }

                if (pos < len && data[pos] == ':') {
                    ++pos;

                    while (pos < len && (data[pos] == ' ' || data[pos] == '\t' || data[pos] == '\n' || data[pos] == '\r')) {
                        ++pos;
                    }

                    if (pos < len && data[pos] == '"') {
                        ++pos;

                        const char* start = data + pos;
                        const char* end = start;

                        while (end < data + len && *end != '"') {
                            if (*end == '\\' && (end + 1) < data + len) {
                                ++end;
                            }
                            ++end;
                        }

                        if (end > start) {
                            return std::string(start, end - start);
                        }
                    }
                }
                break;
            }
        }

        return "";
    }

    CoroutineStarter onPing(const std::shared_ptr<AsyncWebSocket>& socket, const oatpp::String& message) override {
        return socket->sendPongAsync(message);
    }

    CoroutineStarter onPong(const std::shared_ptr<AsyncWebSocket>& socket, const oatpp::String& message) override {
        m_lastPongTime = std::chrono::steady_clock::now();
        OATPP_LOGD("WebSocket", "Received pong from user %s", m_userUuid->c_str());
        return nullptr;
    }

    CoroutineStarter onClose(const std::shared_ptr<AsyncWebSocket>& socket, v_uint16 code, const oatpp::String& message) override {
        m_running = false;
        if (m_heartbeatThread.joinable()) {
            m_heartbeatThread.join();  // 等待线程结束
        }
        if (m_userUuid) {
            m_webSocket->removeConnection(m_userUuid);
            OATPP_LOGI("WebSocket", "User disconnected: %s", m_userUuid->c_str());
        }
        return socket->sendCloseAsync();
    }

    CoroutineStarter readMessage(const std::shared_ptr<AsyncWebSocket>& socket, v_uint8 opcode, p_char8 data, oatpp::v_io_size size) override {
        if (!m_socket) {
            m_socket = socket;
            startHeartbeatCheck();
        }
        if (size == 0) {
            oatpp::String wholeMessage = m_messageBuffer.toString();
            m_messageBuffer.setCurrentPosition(0);
            if (m_userUuid && wholeMessage) {
                handleMessage(wholeMessage);
            }
        }
        else if (size > 0) {
            m_messageBuffer.writeSimple(data, size);
        }
        return nullptr;
    }

private:
    void startHeartbeatCheck() {
        m_heartbeatThread = std::thread([this]() {
            while (m_running) {
                std::this_thread::sleep_for(std::chrono::seconds(1));

                auto now = std::chrono::steady_clock::now();
                auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - m_lastPongTime.load()).count();

                if (elapsed >= PONG_TIMEOUT.count()) {
                    OATPP_LOGW("WebSocket", "Heartbeat timeout for user %s, closing connection", m_userUuid->c_str());
                    if (m_socket && m_running) {
                        m_socket->sendCloseAsync();
                    }
                    break;
                }

                if (elapsed >= HEARTBEAT_INTERVAL.count()) {
                    OATPP_LOGD("WebSocket", "Sending heartbeat to user %s", m_userUuid->c_str());
                    if (m_socket && m_running) {
                        m_socket->sendPingAsync("heartbeat");
                    }
                }
            }
        });
    }
    void handleMessage(const oatpp::String& message) {
        if (!message || message->empty()) {
            sendError("Empty message");
            return;
        }

        auto type = quickExtractType(message);
        if (type.empty()) {
            sendError("Missing message type");
            return;
        }

        auto it = m_handlers.find(type);
        if (it == m_handlers.end()) {
            OATPP_LOGW("WebSocket", "Unknown message type: %s", type.c_str());
            sendError("Unknown message type: " + type);
            return;
        }

        try {
            OATPP_LOGI("WebSocket", "Processing message type: %s from user: %s", type.c_str(), m_userUuid->c_str());
            it->second(m_userUuid, message);
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error handling message: %s", e.what());
            sendError("Internal error");
        }
    }

    void sendError(const oatpp::String& errorMessage) {
        auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
        response->type = "error";
        response->content = errorMessage;
        response->success = false;
        if (m_userUuid && m_webSocket) {
            m_webSocket->sendMessageToUser(m_userUuid, m_objectMapper->writeToString(response));
        }
    }

    // ========== 会话相关处理方法 (ConversationController) ==========

    void handleGetConversations(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto result = m_conversationService->getConversations(userUuid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_conversations_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting conversations: %s", e.what());
            sendError("Failed to get conversations");
        }
    }

    void handleMarkConversationRead(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid conversation data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto convid = request["convid"];
            if (!convid) {
                sendError("Conversation ID is required");
                return;
            }
            auto result = m_conversationService->markConversationRead(userUuid, convid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "mark_conversation_read_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error marking conversation read: %s", e.what());
            sendError("Failed to mark conversation read");
        }
    }

    // ========== 好友相关处理方法 (FriendController) ==========

    void handleSendFriendRequest(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid friend request data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Object<SendFriendRequestDTO>>(dto->content);
            auto result = m_friendService->sendFriendRequest(userUuid, request);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "send_friend_request_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error sending friend request: %s", e.what());
            sendError("Failed to send friend request");
        }
    }

    void handleGetSentRequests(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto result = m_friendService->getSentRequests(userUuid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_sent_requests_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting sent requests: %s", e.what());
            sendError("Failed to get sent requests");
        }
    }

    void handleGetReceivedRequests(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto result = m_friendService->getReceivedRequests(userUuid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_received_requests_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting received requests: %s", e.what());
            sendError("Failed to get received requests");
        }
    }

    void handleAcceptFriendRequest(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid request data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto requid = request["requid"];
            if (!requid) {
                sendError("Request ID is required");
                return;
            }
            auto result = m_friendService->acceptFriendRequest(userUuid, requid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "accept_friend_request_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error accepting friend request: %s", e.what());
            sendError("Failed to accept friend request");
        }
    }

    void handleRejectFriendRequest(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid request data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto requid = request["requid"];
            if (!requid) {
                sendError("Request ID is required");
                return;
            }
            auto result = m_friendService->rejectFriendRequest(requid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "reject_friend_request_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error rejecting friend request: %s", e.what());
            sendError("Failed to reject friend request");
        }
    }

    void handleCancelFriendRequest(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid request data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto requid = request["requid"];
            if (!requid) {
                sendError("Request ID is required");
                return;
            }
            auto result = m_friendService->cancelFriendRequest(requid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "cancel_friend_request_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error canceling friend request: %s", e.what());
            sendError("Failed to cancel friend request");
        }
    }

    void handleGetFriends(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto result = m_friendService->getFriends(userUuid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_friends_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting friends: %s", e.what());
            sendError("Failed to get friends");
        }
    }

    void handleUpdateFriendRemark(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid friend data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto friendId = request["friendId"];
            if (!friendId) {
                sendError("Friend ID is required");
                return;
            }
            auto remarkRequest = m_objectMapper->readFromString<oatpp::Object<UpdateFriendRemarkDTO>>(dto->content);
            auto result = m_friendService->updateFriendRemark(userUuid, friendId, remarkRequest);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "update_friend_remark_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error updating friend remark: %s", e.what());
            sendError("Failed to update friend remark");
        }
    }

    void handleUpdateFriendGroup(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid friend data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto friendId = request["friendId"];
            if (!friendId) {
                sendError("Friend ID is required");
                return;
            }
            auto groupRequest = m_objectMapper->readFromString<oatpp::Object<UpdateFriendGroupDTO>>(dto->content);
            auto result = m_friendService->updateFriendGroup(userUuid, friendId, groupRequest);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "update_friend_group_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error updating friend group: %s", e.what());
            sendError("Failed to update friend group");
        }
    }

    void handleDeleteFriend(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid friend data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto friendId = request["friendId"];
            if (!friendId) {
                sendError("Friend ID is required");
                return;
            }
            auto result = m_friendService->deleteFriend(userUuid, friendId);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "delete_friend_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error deleting friend: %s", e.what());
            sendError("Failed to delete friend");
        }
    }

    void handleBlockUser(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid user data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto targetUserId = request["targetUserId"];
            if (!targetUserId) {
                sendError("Target user ID is required");
                return;
            }
            auto result = m_friendService->blockUser(userUuid, targetUserId);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "block_user_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error blocking user: %s", e.what());
            sendError("Failed to block user");
        }
    }

    void handleUnblockUser(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid user data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto targetUserId = request["targetUserId"];
            if (!targetUserId) {
                sendError("Target user ID is required");
                return;
            }
            auto result = m_friendService->unblockUser(userUuid, targetUserId);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "unblock_user_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error unblocking user: %s", e.what());
            sendError("Failed to unblock user");
        }
    }

    // ========== 群组相关处理方法 (GroupController) ==========

    void handleCreateGroup(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Object<CreateGroupRequestDTO>>(dto->content);
            auto result = m_groupService->createGroup(userUuid, request);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "create_group_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error creating group: %s", e.what());
            sendError("Failed to create group");
        }
    }

    void handleGetMyGroups(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto result = m_groupService->getMyGroups(userUuid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_my_groups_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting my groups: %s", e.what());
            sendError("Failed to get my groups");
        }
    }

    void handleGetGroupDetail(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            auto result = m_groupService->getGroupDetail(userUuid, gid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_group_detail_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting group detail: %s", e.what());
            sendError("Failed to get group detail");
        }
    }

    void handleUpdateGroup(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            auto updateRequest = m_objectMapper->readFromString<oatpp::Object<UpdateGroupRequestDTO>>(dto->content);
            auto result = m_groupService->updateGroup(userUuid, gid, updateRequest);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "update_group_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error updating group: %s", e.what());
            sendError("Failed to update group");
        }
    }

    void handleDissolveGroup(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            auto result = m_groupService->dissolveGroup(userUuid, gid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "dissolve_group_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error dissolving group: %s", e.what());
            sendError("Failed to dissolve group");
        }
    }

    void handleGetGroupMembers(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            auto result = m_groupService->getGroupMembers(gid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_group_members_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting group members: %s", e.what());
            sendError("Failed to get group members");
        }
    }

    void handleAddGroupMembers(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            auto addRequest = m_objectMapper->readFromString<oatpp::Object<AddGroupMemberRequestDTO>>(dto->content);
            auto result = m_groupService->addGroupMembers(userUuid, gid, addRequest);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "add_group_members_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error adding group members: %s", e.what());
            sendError("Failed to add group members");
        }
    }

    void handleRemoveGroupMember(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            auto uid = request["uid"];
            if (!gid || !uid) {
                sendError("Group ID and User ID are required");
                return;
            }
            auto result = m_groupService->removeGroupMember(userUuid, gid, uid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "remove_group_member_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error removing group member: %s", e.what());
            sendError("Failed to remove group member");
        }
    }

    void handleSetMemberRole(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            auto uid = request["uid"];
            if (!gid || !uid) {
                sendError("Group ID and User ID are required");
                return;
            }
            auto roleRequest = m_objectMapper->readFromString<oatpp::Object<SetMemberRoleRequestDTO>>(dto->content);
            auto result = m_groupService->setMemberRole(userUuid, gid, uid, roleRequest);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "set_member_role_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error setting member role: %s", e.what());
            sendError("Failed to set member role");
        }
    }

    void handleJoinGroup(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            auto result = m_groupService->joinGroup(userUuid, gid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "join_group_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error joining group: %s", e.what());
            sendError("Failed to join group");
        }
    }

    void handleLeaveGroup(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            auto result = m_groupService->leaveGroup(userUuid, gid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "leave_group_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error leaving group: %s", e.what());
            sendError("Failed to leave group");
        }
    }

    // ========== 消息历史相关处理方法 (MessageController) ==========

    void handleGetPrivateMessages(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid message data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto uid = request["uid"];
            if (!uid) {
                sendError("User ID is required");
                return;
            }
            auto result = m_messageService->getPrivateMessages(userUuid, uid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_private_messages_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting private messages: %s", e.what());
            sendError("Failed to get private messages");
        }
    }

    void handleGetPrivateMessagesPage(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid message data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto uid = request["uid"];
            auto pageStr = request["page"];
            auto sizeStr = request["size"];
            if (!uid) {
                sendError("User ID is required");
                return;
            }
            oatpp::Int32 page = 1;
            oatpp::Int32 size = 50;
            if (pageStr) {
                page = std::stoi(pageStr->c_str());
            }
            if (sizeStr) {
                size = std::stoi(sizeStr->c_str());
            }
            auto result = m_messageService->getPrivateMessagesPage(userUuid, uid, page, size);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_private_messages_page_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting private messages page: %s", e.what());
            sendError("Failed to get private messages page");
        }
    }

    void handleGetGroupMessages(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            auto result = m_messageService->getGroupMessages(userUuid, gid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_group_messages_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting group messages: %s", e.what());
            sendError("Failed to get group messages");
        }
    }

    void handleGetGroupMessagesPage(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid group data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto gid = request["gid"];
            auto pageStr = request["page"];
            auto sizeStr = request["size"];
            if (!gid) {
                sendError("Group ID is required");
                return;
            }
            oatpp::Int32 page = 1;
            oatpp::Int32 size = 50;
            if (pageStr) {
                page = std::stoi(pageStr->c_str());
            }
            if (sizeStr) {
                size = std::stoi(sizeStr->c_str());
            }
            auto result = m_messageService->getGroupMessagesPage(userUuid, gid, page, size);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_group_messages_page_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting group messages page: %s", e.what());
            sendError("Failed to get group messages page");
        }
    }

    void handleSendPrivateMessage(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid message data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Object<SendPrivateMessageRequestDTO>>(dto->content);
            auto result = m_messageService->sendPrivateMessage(userUuid, request);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "send_private_message_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error sending private message: %s", e.what());
            sendError("Failed to send private message");
        }
    }

    void handleMarkMessageRead(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid message data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto mid = request["mid"];
            if (!mid) {
                sendError("Message ID is required");
                return;
            }
            auto result = m_messageService->markMessageRead(userUuid, mid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "mark_message_read_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error marking message read: %s", e.what());
            sendError("Failed to mark message read");
        }
    }

    void handleRecallMessage(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid message data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
            auto mid = request["mid"];
            if (!mid) {
                sendError("Message ID is required");
                return;
            }
            auto result = m_messageService->recallMessage(userUuid, mid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "recall_message_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error recalling message: %s", e.what());
            sendError("Failed to recall message");
        }
    }

    void handleSendGroupMessage(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid message data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Object<SendGroupMessageRequestDTO>>(dto->content);
            auto result = m_messageService->sendGroupMessage(userUuid, request);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "send_group_message_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error sending group message: %s", e.what());
            sendError("Failed to send group message");
        }
    }

    // ========== 通知相关处理方法 (NotificationController) ==========

    //void handleGetNotifications(const oatpp::String& userUuid, const oatpp::String& msg) {
    //    try {
    //        auto result = m_notificationService->getNotifications(userUuid);
    //        auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
    //        response->type = "get_notifications_response";
    //        response->content = m_objectMapper->writeToString(result);
    //        response->success = true;
    //        m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
    //    } catch (const std::exception& e) {
    //        OATPP_LOGE("WebSocket", "Error getting notifications: %s", e.what());
    //        sendError("Failed to get notifications");
    //    }
    //}

    //void handleGetUnreadCount(const oatpp::String& userUuid, const oatpp::String& msg) {
    //    try {
    //        auto result = m_notificationService->getUnreadCount(userUuid);
    //        auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
    //        response->type = "get_unread_count_response";
    //        response->content = m_objectMapper->writeToString(result);
    //        response->success = true;
    //        m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
    //    } catch (const std::exception& e) {
    //        OATPP_LOGE("WebSocket", "Error getting unread count: %s", e.what());
    //        sendError("Failed to get unread count");
    //    }
    //}

    //void handleMarkNotificationRead(const oatpp::String& userUuid, const oatpp::String& msg) {
    //    try {
    //        auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
    //        if (!dto || !dto->content) {
    //            sendError("Invalid notification data");
    //            return;
    //        }
    //        auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
    //        auto id = request["id"];
    //        if (!id) {
    //            sendError("Notification ID is required");
    //            return;
    //        }
    //        auto result = m_notificationService->markAsRead(userUuid, id);
    //        auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
    //        response->type = "mark_notification_read_response";
    //        response->content = m_objectMapper->writeToString(result);
    //        response->success = true;
    //        m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
    //    } catch (const std::exception& e) {
    //        OATPP_LOGE("WebSocket", "Error marking notification read: %s", e.what());
    //        sendError("Failed to mark notification read");
    //    }
    //}

    //void handleMarkAllNotificationsRead(const oatpp::String& userUuid, const oatpp::String& msg) {
    //    try {
    //        auto result = m_notificationService->markAllAsRead(userUuid);
    //        auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
    //        response->type = "mark_all_notifications_read_response";
    //        response->content = m_objectMapper->writeToString(result);
    //        response->success = true;
    //        m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
    //    } catch (const std::exception& e) {
    //        OATPP_LOGE("WebSocket", "Error marking all notifications read: %s", e.what());
    //        sendError("Failed to mark all notifications read");
    //    }
    //}

    //void handleDeleteNotification(const oatpp::String& userUuid, const oatpp::String& msg) {
    //    try {
    //        auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
    //        if (!dto || !dto->content) {
    //            sendError("Invalid notification data");
    //            return;
    //        }
    //        auto request = m_objectMapper->readFromString<oatpp::Fields<oatpp::String>>(dto->content);
    //        auto id = request["id"];
    //        if (!id) {
    //            sendError("Notification ID is required");
    //            return;
    //        }
    //        auto result = m_notificationService->deleteNotification(userUuid, id);
    //        auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
    //        response->type = "delete_notification_response";
    //        response->content = m_objectMapper->writeToString(result);
    //        response->success = true;
    //        m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
    //    } catch (const std::exception& e) {
    //        OATPP_LOGE("WebSocket", "Error deleting notification: %s", e.what());
    //        sendError("Failed to delete notification");
    //    }
    //}

    //void handleBatchDeleteNotifications(const oatpp::String& userUuid, const oatpp::String& msg) {
    //    try {
    //        auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
    //        if (!dto || !dto->content) {
    //            sendError("Invalid notification data");
    //            return;
    //        }
    //        auto request = m_objectMapper->readFromString<oatpp::Object<BatchDeleteNotificationsRequest>>(dto->content);
    //        auto result = m_notificationService->batchDeleteNotifications(userUuid, request);
    //        auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
    //        response->type = "batch_delete_notifications_response";
    //        response->content = m_objectMapper->writeToString(result);
    //        response->success = true;
    //        m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
    //    } catch (const std::exception& e) {
    //        OATPP_LOGE("WebSocket", "Error batch deleting notifications: %s", e.what());
    //        sendError("Failed to batch delete notifications");
    //    }
    //}

    //void handleClearNotifications(const oatpp::String& userUuid, const oatpp::String& msg) {
    //    try {
    //        auto result = m_notificationService->clearNotifications(userUuid);
    //        auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
    //        response->type = "clear_notifications_response";
    //        response->content = m_objectMapper->writeToString(result);
    //        response->success = true;
    //        m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
    //    } catch (const std::exception& e) {
    //        OATPP_LOGE("WebSocket", "Error clearing notifications: %s", e.what());
    //        sendError("Failed to clear notifications");
    //    }
    //}

    // ========== 用户状态相关处理方法 (UserStatusController) ==========

    void handleUpdateStatus(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid status data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Object<UpdateStatusRequestDTO>>(dto->content);
            auto result = m_statusService->updateStatus(userUuid, request);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "update_status_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error updating status: %s", e.what());
            sendError("Failed to update status");
        }
    }

    void handleGetMultipleStatuses(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid user data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Object<BatchStatusRequestDTO>>(dto->content);
            auto result = m_statusService->getMultipleStatuses(userUuid, request);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_multiple_statuses_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting multiple statuses: %s", e.what());
            sendError("Failed to get multiple statuses");
        }
    }

    void handleGetCurrentUser(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto result = m_statusService->getCurrentUser(userUuid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "get_current_user_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error getting current user: %s", e.what());
            sendError("Failed to get current user");
        }
    }

    void handleUpdateUserInfo(const oatpp::String& userUuid, const oatpp::String& msg) {
        try {
            auto dto = m_objectMapper->readFromString<oatpp::Object<WebSocketMessageDTO>>(msg);
            if (!dto || !dto->content) {
                sendError("Invalid user data");
                return;
            }
            auto request = m_objectMapper->readFromString<oatpp::Object<UpdateProfileRequestDTO>>(dto->content);
            auto result = m_statusService->updateUserInfo(request, userUuid);
            auto response = oatpp::Object<WebSocketResponseDTO>::createShared();
            response->type = "update_user_info_response";
            response->content = m_objectMapper->writeToString(result);
            response->success = true;
            m_webSocket->sendMessageToUser(userUuid, m_objectMapper->writeToString(response));
        } catch (const std::exception& e) {
            OATPP_LOGE("WebSocket", "Error updating user info: %s", e.what());
            sendError("Failed to update user info");
        }
    }
};
